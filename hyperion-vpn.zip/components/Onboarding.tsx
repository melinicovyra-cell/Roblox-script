import React, { useState } from 'react';
import { Shield, Zap, Globe, ChevronRight } from 'lucide-react';
import { t } from '../utils/i18n';

const Onboarding = ({ onComplete, settings }: any) => {
  const [slide, setSlide] = useState(0);
  const slides = [
    { icon: <Shield size={64} />, title: 'privacyTitle', desc: 'privacyDesc' },
    { icon: <Zap size={64} />, title: 'speedTitle', desc: 'speedDesc' },
    { icon: <Globe size={64} />, title: 'globalTitle', desc: 'globalDesc' }
  ];

  const next = () => {
    if (slide < slides.length - 1) setSlide(slide + 1);
    else onComplete();
  };

  return (
    <div className="fixed inset-0 bg-[#0b1121] flex flex-col items-center justify-center p-8 z-40">
      <div className="text-indigo-400 mb-8 animate-bounce">{slides[slide].icon}</div>
      <h2 className="text-2xl font-bold text-white mb-4 text-center">{t(settings.language, slides[slide].title)}</h2>
      <p className="text-slate-400 text-center mb-12">{t(settings.language, slides[slide].desc)}</p>
      <button onClick={next} className="bg-indigo-600 text-white p-4 rounded-full shadow-lg">
        <ChevronRight size={24} />
      </button>
    </div>
  );
};
export default Onboarding;