import React from 'react';
import { ShieldCheck, Check } from 'lucide-react';
import { themes } from '../utils/theme';
import { t } from '../utils/i18n';

const PrivacyPolicy = ({ onAgree, settings }: any) => {
  const theme = themes[settings.theme as keyof typeof themes];
  const lang = settings.language;

  return (
    <div className={`fixed inset-0 z-40 flex items-center justify-center p-6 ${theme.bg}`}>
      <div className={`w-full max-w-md ${theme.cardBg} border ${theme.border} p-8 rounded-3xl shadow-2xl`}>
        <div className="flex flex-col items-center mb-6">
          <ShieldCheck className={`w-12 h-12 ${theme.accent} mb-4`} />
          <h2 className={`text-2xl font-bold ${theme.textPrimary}`}>{t(lang, 'privacyPolicy')}</h2>
        </div>
        <p className={`mb-8 text-sm ${theme.textSecondary}`}>{t(lang, 'privacyContent')}</p>
        <button onClick={onAgree} className={`w-full py-4 rounded-xl font-bold ${theme.buttonBg} ${theme.buttonText}`}>
          {t(lang, 'agreeAndContinue')}
        </button>
      </div>
    </div>
  );
};
export default PrivacyPolicy;