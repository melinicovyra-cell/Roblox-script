import React, { useEffect, useState } from 'react';
import { Settings, Power, ArrowDown, ArrowUp, Globe, MoreVertical } from 'lucide-react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';
import { formatSpeed } from '../utils/vless';
import { themes } from '../utils/theme';
import { t } from '../utils/i18n';

const Dashboard = ({ status, selectedServer, settings, onToggleConnection, onOpenServers, onOpenSettings, connectionTime }: any) => {
  const [data, setData] = useState(Array(20).fill({ up: 0, down: 0 }));
  const theme = themes[settings.theme as keyof typeof themes];
  const isLight = settings.theme === 'light';

  useEffect(() => {
    if (status !== 'connected') return;
    const interval = setInterval(() => {
      setData(prev => [...prev.slice(1), { up: Math.random() * 100, down: Math.random() * 500 }]);
    }, 1000);
    return () => clearInterval(interval);
  }, [status]);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    return `${m}:${sec}`;
  };

  return (
    <div className={`h-screen w-full flex flex-col ${theme.bg} overflow-hidden p-6 relative`}>
      <header className="flex justify-between items-center z-10">
        <h1 className={`text-xl font-bold ${theme.textPrimary}`}>Hyperion</h1>
        <button onClick={onOpenSettings}><Settings className={theme.textPrimary} /></button>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center z-10">
        <div className="relative mb-12">
          {status === 'connected' && <div className="absolute inset-0 bg-emerald-500 blur-3xl opacity-20 animate-pulse" />}
          <button 
            onClick={onToggleConnection}
            className={`w-40 h-40 rounded-full flex items-center justify-center shadow-2xl transition-all duration-500 ${status === 'connected' ? 'bg-emerald-500 shadow-emerald-500/50' : 'bg-slate-800 shadow-black'}`}
          >
            <Power size={48} className="text-white" />
          </button>
        </div>
        
        <div className={`text-4xl font-mono mb-2 ${theme.textPrimary}`}>
          {status === 'connected' ? formatTime(connectionTime) : t(settings.language, status)}
        </div>
        
        <button onClick={onOpenServers} className={`flex items-center gap-3 px-6 py-3 rounded-full border ${theme.border} ${theme.cardBg} mt-8 w-full max-w-xs`}>
          <Globe className={theme.accent} />
          <div className="flex-1 text-left">
            <div className={`text-xs ${theme.textSecondary}`}>{t(settings.language, 'currentLocation')}</div>
            <div className={`font-bold ${theme.textPrimary}`}>{selectedServer?.name || t(settings.language, 'selectServer')}</div>
          </div>
          <MoreVertical size={16} className={theme.textSecondary} />
        </button>
      </main>

      <div className="grid grid-cols-2 gap-4 h-32 z-10">
        <div className={`${theme.cardBg} rounded-2xl p-4 border ${theme.border} relative overflow-hidden`}>
           <div className={`text-xs ${theme.textSecondary} flex gap-2`}><ArrowDown size={14} /> Download</div>
           <div className={`text-lg font-bold ${theme.textPrimary}`}>{status === 'connected' ? '45.2 MB/s' : '0 B/s'}</div>
           <div className="absolute bottom-0 left-0 right-0 h-12 opacity-50">
             <ResponsiveContainer><AreaChart data={data}><Area type="monotone" dataKey="down" stroke="#10b981" fill="#10b981" /></AreaChart></ResponsiveContainer>
           </div>
        </div>
        <div className={`${theme.cardBg} rounded-2xl p-4 border ${theme.border} relative overflow-hidden`}>
           <div className={`text-xs ${theme.textSecondary} flex gap-2`}><ArrowUp size={14} /> Upload</div>
           <div className={`text-lg font-bold ${theme.textPrimary}`}>{status === 'connected' ? '12.8 MB/s' : '0 B/s'}</div>
           <div className="absolute bottom-0 left-0 right-0 h-12 opacity-50">
             <ResponsiveContainer><AreaChart data={data}><Area type="monotone" dataKey="up" stroke="#6366f1" fill="#6366f1" /></AreaChart></ResponsiveContainer>
           </div>
        </div>
      </div>
    </div>
  );
};
export default Dashboard;