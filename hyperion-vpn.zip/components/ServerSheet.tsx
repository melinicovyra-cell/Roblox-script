import React, { useState } from 'react';
import { X, Plus, Check, Trash2, Globe, Server, Copy } from 'lucide-react';
import { parseVlessLink } from '../utils/vless';
import { themes } from '../utils/theme';
import { t } from '../utils/i18n';

const ServerSheet = ({ isOpen, onClose, servers, selectedId, settings, onSelect, onAdd, onDelete }: any) => {
  const [showAdd, setShowAdd] = useState(false);
  const [link, setLink] = useState('');
  const theme = themes[settings.theme as keyof typeof themes];
  const lang = settings.language;

  const handleAdd = () => {
    const config = parseVlessLink(link);
    if (config) {
      onAdd(config);
      setLink('');
      setShowAdd(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className={`relative w-full max-w-md ${settings.theme === 'light' ? 'bg-white' : 'bg-slate-900'} rounded-t-3xl p-6 h-[80vh] flex flex-col`}>
        <div className="flex justify-between mb-4">
          <h2 className={`font-bold ${theme.textPrimary}`}>{t(lang, 'locations')}</h2>
          <button onClick={onClose}><X className={theme.textPrimary} /></button>
        </div>
        
        {showAdd ? (
          <div className="mb-4">
            <textarea value={link} onChange={e => setLink(e.target.value)} placeholder="vless://..." className="w-full bg-slate-800 text-white p-2 rounded mb-2 h-20" />
            <div className="flex gap-2">
              <button onClick={() => setShowAdd(false)} className="flex-1 p-2 border border-slate-600 rounded text-slate-400">Cancel</button>
              <button onClick={handleAdd} className="flex-1 p-2 bg-indigo-600 rounded text-white">Add</button>
            </div>
          </div>
        ) : (
          <button onClick={() => setShowAdd(true)} className={`w-full py-3 border ${theme.border} rounded-xl mb-4 text-indigo-400`}>
            + {t(lang, 'addConnection')}
          </button>
        )}

        <div className="flex-1 overflow-auto space-y-2">
          {servers.map((s: any) => (
            <div key={s.id} onClick={() => { onSelect(s); onClose(); }} className={`p-4 rounded-xl border ${selectedId === s.id ? 'border-indigo-500 bg-indigo-500/10' : theme.border} cursor-pointer flex justify-between`}>
              <div className={theme.textPrimary}>{s.name}</div>
              {selectedId === s.id && <Check size={16} className="text-indigo-500" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default ServerSheet;