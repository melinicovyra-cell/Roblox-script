import React, { useState } from 'react';
import { Mail, Lock, User, ArrowRight } from 'lucide-react';
import { themes } from '../utils/theme';
import { t } from '../utils/i18n';

const Auth = ({ onComplete, settings }: any) => {
  const [mode, setMode] = useState('login');
  const theme = themes[settings.theme as keyof typeof themes];
  const lang = settings.language;

  const handleSubmit = (e: any) => {
    e.preventDefault();
    onComplete({ name: 'User', email: 'user@example.com' });
  };

  return (
    <div className={`fixed inset-0 z-40 flex items-center justify-center p-6 ${theme.bg}`}>
      <div className={`w-full max-w-sm ${theme.cardBg} border ${theme.border} p-8 rounded-3xl`}>
        <h2 className={`text-3xl font-bold ${theme.textPrimary} mb-6`}>{t(lang, mode)}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className={`flex items-center border-b ${theme.border} py-2`}>
            <Mail className={theme.textSecondary} size={20} />
            <input className={`bg-transparent w-full ml-4 outline-none ${theme.textPrimary}`} placeholder={t(lang, 'email')} required />
          </div>
          <div className={`flex items-center border-b ${theme.border} py-2`}>
            <Lock className={theme.textSecondary} size={20} />
            <input type="password" className={`bg-transparent w-full ml-4 outline-none ${theme.textPrimary}`} placeholder={t(lang, 'password')} required />
          </div>
          <button type="submit" className={`w-full py-3 mt-4 rounded-xl font-bold ${theme.buttonBg} ${theme.buttonText}`}>
            {t(lang, mode)}
          </button>
        </form>
        <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')} className={`mt-4 text-sm ${theme.accent} w-full text-center`}>
           Switch to {mode === 'login' ? 'Register' : 'Login'}
        </button>
      </div>
    </div>
  );
};
export default Auth;