import React from 'react';
import { X, Moon, Sun, Zap, Globe } from 'lucide-react';
import { themes } from '../utils/theme';
import { t } from '../utils/i18n';

const SettingsSheet = ({ isOpen, onClose, settings, onUpdateSettings }: any) => {
  if (!isOpen) return null;
  const theme = themes[settings.theme as keyof typeof themes];
  
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className={`relative w-full max-w-md ${settings.theme === 'light' ? 'bg-white' : 'bg-slate-900'} rounded-t-3xl p-6`}>
        <div className="flex justify-between mb-6">
          <h2 className={`font-bold ${theme.textPrimary}`}>{t(settings.language, 'settings')}</h2>
          <button onClick={onClose}><X className={theme.textPrimary} /></button>
        </div>
        <div className="space-y-6">
          <div>
            <label className={`block mb-2 text-sm ${theme.textSecondary}`}>Theme</label>
            <div className="flex gap-2">
              {['neon', 'dark', 'light'].map(m => (
                <button key={m} onClick={() => onUpdateSettings({...settings, theme: m})} className={`flex-1 p-2 rounded border ${settings.theme === m ? 'border-indigo-500 text-indigo-500' : 'border-slate-700 text-slate-500'}`}>
                  {m}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className={`block mb-2 text-sm ${theme.textSecondary}`}>Language</label>
            <div className="flex gap-2">
              <button onClick={() => onUpdateSettings({...settings, language: 'en'})} className={`flex-1 p-2 rounded border ${settings.language === 'en' ? 'border-indigo-500' : 'border-slate-700 text-slate-500'}`}>EN</button>
              <button onClick={() => onUpdateSettings({...settings, language: 'ru'})} className={`flex-1 p-2 rounded border ${settings.language === 'ru' ? 'border-indigo-500' : 'border-slate-700 text-slate-500'}`}>RU</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SettingsSheet;