import React, { useEffect, useState } from 'react';
import { Zap } from 'lucide-react';

const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  const [opacity, setOpacity] = useState(100);

  useEffect(() => {
    const timer = setTimeout(() => {
      setOpacity(0);
      setTimeout(onFinish, 500);
    }, 2000);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div 
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 transition-opacity duration-500"
      style={{ opacity: opacity / 100, pointerEvents: opacity === 0 ? 'none' : 'auto' }}
    >
      <Zap size={48} className="text-indigo-400 animate-bounce" fill="currentColor" />
      <h1 className="mt-8 text-3xl font-bold text-white">Hyperion<span className="text-indigo-500">.</span></h1>
    </div>
  );
};
export default SplashScreen;