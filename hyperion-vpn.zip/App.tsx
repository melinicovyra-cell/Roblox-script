import React, { useState, useEffect } from 'react';
import SplashScreen from './components/SplashScreen';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import ServerSheet from './components/ServerSheet';
import SettingsSheet from './components/SettingsSheet';
import PrivacyPolicy from './components/PrivacyPolicy';
import Auth from './components/Auth';
import { parseVlessLink } from './utils/vless';

// Место для вашей VLESS ссылки
const SAMPLE_LINK = "vless://ddc2716c-8b78-49dc-baa6-495f98f20ba6@95.163.210.176:443?encryption=none&fp=chrome&security=reality&type=tcp#MyServer";

const App = () => {
  const [view, setView] = useState('splash');
  const [status, setStatus] = useState('disconnected');
  const [servers, setServers] = useState([]);
  const [selectedServer, setSelectedServer] = useState(null);
  const [settings, setSettings] = useState({ theme: 'neon', language: 'en', splitTunneling: false, routingMode: 'rule-based', notifications: true });
  const [sheets, setSheets] = useState({ servers: false, settings: false });
  const [time, setTime] = useState(0);

  useEffect(() => {
    // Автоматическое добавление примера сервера
    const config = parseVlessLink(SAMPLE_LINK);
    if (config) {
      setServers([config]);
      setSelectedServer(config);
    }
  }, []);

  useEffect(() => {
    let interval;
    if (status === 'connected') interval = setInterval(() => setTime(t => t + 1), 1000);
    else setTime(0);
    return () => clearInterval(interval);
  }, [status]);

  const toggleConnect = () => {
    if (!selectedServer) return setSheets({ ...sheets, servers: true });
    if (status === 'disconnected') {
      setStatus('connecting');
      setTimeout(() => setStatus('connected'), 1500);
    } else setStatus('disconnected');
  };

  return (
    <>
      {view === 'splash' && <SplashScreen onFinish={() => setView('privacy')} />}
      {view === 'privacy' && <PrivacyPolicy onAgree={() => setView('auth')} settings={settings} />}
      {view === 'auth' && <Auth onComplete={() => setView('onboarding')} settings={settings} />}
      {view === 'onboarding' && <Onboarding onComplete={() => setView('dashboard')} settings={settings} />}
      {view === 'dashboard' && (
        <>
          <Dashboard 
            status={status} selectedServer={selectedServer} settings={settings} connectionTime={time}
            onToggleConnection={toggleConnect} 
            onOpenServers={() => setSheets({ ...sheets, servers: true })}
            onOpenSettings={() => setSheets({ ...sheets, settings: true })}
          />
          <ServerSheet 
            isOpen={sheets.servers} onClose={() => setSheets({ ...sheets, servers: false })}
            servers={servers} selectedId={selectedServer?.id} settings={settings}
            onSelect={setSelectedServer} onAdd={s => setServers([...servers, s])} onDelete={id => setServers(servers.filter(s => s.id !== id))}
          />
          <SettingsSheet 
            isOpen={sheets.settings} onClose={() => setSheets({ ...sheets, settings: false })}
            settings={settings} onUpdateSettings={setSettings}
          />
        </>
      )}
    </>
  );
};
export default App;