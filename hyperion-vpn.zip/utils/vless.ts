import { VlessConfig } from '../types';

export const parseVlessLink = (link: string): VlessConfig | null => {
  try {
    if (!link.startsWith('vless://')) return null;

    const url = new URL(link);
    const params = new URLSearchParams(url.search);
    const hash = url.hash.substring(1);

    return {
      id: crypto.randomUUID(),
      uuid: url.username,
      address: url.hostname,
      port: parseInt(url.port, 10),
      name: hash ? decodeURIComponent(hash) : `${url.hostname}:${url.port}`,
      encryption: params.get('encryption') || 'none',
      security: params.get('security') || undefined,
      type: params.get('type') || 'tcp',
      sni: params.get('sni') || undefined,
      fp: params.get('fp') || undefined,
      pbk: params.get('pbk') || undefined,
      sid: params.get('sid') || undefined,
      originalLink: link,
    };
  } catch (error) {
    console.error("Failed to parse VLESS link", error);
    return null;
  }
};

export const formatSpeed = (bytes: number): string => {
  if (bytes < 1024) return `${bytes.toFixed(0)} B/s`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB/s`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB/s`;
};