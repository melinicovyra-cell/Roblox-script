import { Theme } from '../types';

export const themes = {
  neon: {
    bg: 'bg-[#0b1121]',
    bgGradient: 'from-slate-900 to-[#0b1121]',
    cardBg: 'bg-slate-800/40 backdrop-blur-xl',
    textPrimary: 'text-white',
    textSecondary: 'text-slate-400',
    accent: 'text-indigo-400',
    accentGlow: 'bg-indigo-500',
    border: 'border-slate-700/50',
    buttonBg: 'bg-indigo-600 hover:bg-indigo-500',
    buttonText: 'text-white',
  },
  dark: {
    bg: 'bg-black',
    bgGradient: 'from-neutral-900 to-black',
    cardBg: 'bg-neutral-900/80 backdrop-blur-md',
    textPrimary: 'text-neutral-100',
    textSecondary: 'text-neutral-500',
    accent: 'text-white',
    accentGlow: 'bg-white',
    border: 'border-neutral-800',
    buttonBg: 'bg-white hover:bg-neutral-200',
    buttonText: 'text-black',
  },
  light: {
    bg: 'bg-slate-50',
    bgGradient: 'from-white to-slate-100',
    cardBg: 'bg-white/80 backdrop-blur-xl shadow-lg',
    textPrimary: 'text-slate-900',
    textSecondary: 'text-slate-500',
    accent: 'text-sky-500',
    accentGlow: 'bg-sky-500',
    border: 'border-slate-200',
    buttonBg: 'bg-sky-500 hover:bg-sky-400',
    buttonText: 'text-white',
  }
};