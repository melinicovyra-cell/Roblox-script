export interface VlessConfig {
  id: string;
  uuid: string;
  address: string;
  port: number;
  name: string;
  encryption?: string;
  security?: string;
  type?: string;
  sni?: string;
  fp?: string;
  pbk?: string;
  sid?: string;
  originalLink: string;
}

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected';
export type AppView = 'splash' | 'privacy' | 'auth' | 'onboarding' | 'dashboard';

export interface TrafficData {
  time: string;
  upload: number;
  download: number;
}

export type Theme = 'neon' | 'dark' | 'light';
export type Language = 'en' | 'ru';

export interface User {
  name: string;
  email: string;
}

export interface AppSettings {
  theme: Theme;
  language: Language;
  splitTunneling: boolean;
  routingMode: 'global' | 'rule-based' | 'direct';
  notifications: boolean;
}